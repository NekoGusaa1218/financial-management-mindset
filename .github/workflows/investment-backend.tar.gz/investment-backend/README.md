# 投资模拟系统 - 完整后端版

完整的投资模拟系统，包含前端HTML和后端Node.js API。

## 📋 功能特性

### 用户功能
- ✅ 用户登录认证（JWT）
- ✅ 查看个人资金和收益率
- ✅ 选择投资项目
- ✅ 查看投资历史记录
- ✅ 投资状态锁定机制

### 管理员功能
- ✅ 查看所有用户投资情况
- ✅ 添加/删除投资项目
- ✅ 设置市场涨跌百分比
- ✅ 结算系统（自动计算收益）
- ✅ 期数管理

## 🚀 快速开始

### 1. 安装依赖

```bash
cd investment-backend
npm install
```

### 2. 初始化数据库

```bash
node init-database.js
```

这将创建：
- 管理员账号: `admin` / `admin`
- 40个用户账号: `user1-user40` / `1234`
- 初始项目: 黄金、股票、债券

### 3. 启动后端服务器

```bash
npm start
```

或使用开发模式（自动重启）：

```bash
npm run dev
```

服务器将在 `http://localhost:3000` 启动

### 4. 打开前端页面

在浏览器中打开 `index.html` 文件

**重要**: 确保前端HTML中的 `API_URL` 设置正确：
```javascript
const API_URL = 'http://localhost:3000/api';
```

## 📁 项目结构

```
investment-backend/
├── server.js           # 主服务器文件
├── database.js         # 数据库连接模块
├── middleware.js       # 认证中间件
├── init-database.js    # 数据库初始化脚本
├── package.json        # 项目依赖
├── .env                # 环境配置
├── index.html          # 前端页面
└── database.sqlite     # SQLite数据库（自动生成）
```

## 🔌 API 端点

### 认证
- `POST /api/login` - 用户登录

### 用户端点
- `GET /api/user` - 获取用户信息
- `GET /api/user/history` - 获取投资历史
- `POST /api/user/invest` - 确认投资

### 项目管理
- `GET /api/projects` - 获取所有项目
- `POST /api/projects` - 添加项目（管理员）
- `DELETE /api/projects/:name` - 删除项目（管理员）

### 管理员端点
- `GET /api/admin/users` - 获取所有用户
- `GET /api/admin/period` - 获取当前期数
- `POST /api/admin/settle` - 执行结算
- `GET /api/admin/user-chart/:username` - 获取用户图表数据

## 🗄️ 数据库结构

### users 表
- id, username, password, role, credit, initial_credit, invested_project

### history 表
- id, user_id, period, action, project, percentage, credit_before, credit_after

### projects 表
- id, name

### periods 表
- id, current_period

### market_data 表
- id, period, project_name, percentage

## 🔐 安全特性

- ✅ 密码使用 bcrypt 加密
- ✅ JWT Token 认证
- ✅ 角色权限控制
- ✅ SQL 注入防护
- ✅ CORS 跨域支持

## 📝 使用流程

1. **用户登录**
   - 使用用户名密码登录
   - 系统返回 JWT Token

2. **用户投资**
   - 选择投资项目
   - 确认投资（资金锁定）

3. **管理员结算**
   - 设置各项目涨跌百分比
   - 执行结算
   - 系统自动计算所有用户收益

4. **查看历史**
   - 用户可查看个人投资历史
   - 管理员可查看所有用户数据

## ⚙️ 环境配置

编辑 `.env` 文件：

```env
PORT=3000                          # 服务器端口
JWT_SECRET=your_secret_key         # JWT密钥（生产环境请修改）
DATABASE_PATH=./database.sqlite    # 数据库路径
```

## 🔧 开发提示

### 重置数据库
```bash
rm database.sqlite
node init-database.js
```

### 查看数据库
```bash
sqlite3 database.sqlite
.tables
SELECT * FROM users;
```

### 测试API
```bash
# 登录
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"user1","password":"1234"}'

# 获取用户信息
curl http://localhost:3000/api/user \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 📊 数据流程

```
用户登录 → 获取Token → 选择项目 → 确认投资 → 等待结算
                                              ↓
管理员登录 → 设置涨跌 → 执行结算 → 更新期数 ← 计算收益
```

## 🐛 故障排查

### 连接错误
- 确保后端服务器正在运行
- 检查 `API_URL` 是否正确
- 检查浏览器控制台错误

### 登录失败
- 确认用户名密码正确
- 检查数据库是否初始化

### CORS 错误
- 确保服务器已启用 CORS
- 检查请求头是否正确

## 📦 部署建议

### 生产环境
1. 修改 `.env` 中的 `JWT_SECRET`
2. 使用 PM2 管理进程
3. 配置 Nginx 反向代理
4. 启用 HTTPS
5. 定期备份数据库

```bash
# 使用 PM2
npm install -g pm2
pm2 start server.js --name investment-api
pm2 save
```

## 📄 许可证

MIT License

## 👨‍💻 技术栈

- **后端**: Node.js + Express
- **数据库**: SQLite3
- **认证**: JWT + bcrypt
- **前端**: 原生 HTML/CSS/JavaScript

---

**开发者**: Claude AI Assistant
**版本**: 1.0.0
**更新日期**: 2026-01-28
