require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('./database');
const { authenticateToken, requireAdmin } = require('./middleware');

const app = express();
const PORT = process.env.PORT || 3000;

// 中间件
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// ==================== 认证相关 ====================

// 登录
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: '用户名和密码不能为空' });
    }

    const user = await db.get(
      'SELECT * FROM users WHERE username = ?',
      [username]
    );

    if (!user) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }

    // 生成JWT
    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
        credit: user.credit,
        initialCredit: user.initial_credit,
        investedProject: user.invested_project
      }
    });
  } catch (error) {
    console.error('登录错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// ==================== 用户相关 ====================

// 获取用户信息
app.get('/api/user', authenticateToken, async (req, res) => {
  try {
    const user = await db.get(
      'SELECT id, username, role, credit, initial_credit, invested_project FROM users WHERE id = ?',
      [req.user.id]
    );

    if (!user) {
      return res.status(404).json({ error: '用户不存在' });
    }

    res.json({
      id: user.id,
      username: user.username,
      role: user.role,
      credit: user.credit,
      initialCredit: user.initial_credit,
      investedProject: user.invested_project
    });
  } catch (error) {
    console.error('获取用户信息错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// 获取用户历史记录
app.get('/api/user/history', authenticateToken, async (req, res) => {
  try {
    const history = await db.query(
      `SELECT * FROM history 
       WHERE user_id = ? 
       ORDER BY created_at DESC`,
      [req.user.id]
    );

    res.json(history);
  } catch (error) {
    console.error('获取历史记录错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// 用户投资
app.post('/api/user/invest', authenticateToken, async (req, res) => {
  try {
    const { project } = req.body;

    if (!project) {
      return res.status(400).json({ error: '请选择投资项目' });
    }

    // 检查用户是否已投资
    const user = await db.get(
      'SELECT invested_project FROM users WHERE id = ?',
      [req.user.id]
    );

    if (user.invested_project) {
      return res.status(400).json({ error: '您已投资项目，请等待结算' });
    }

    // 检查项目是否存在
    const projectExists = await db.get(
      'SELECT * FROM projects WHERE name = ?',
      [project]
    );

    if (!projectExists) {
      return res.status(400).json({ error: '投资项目不存在' });
    }

    // 获取当前期数
    const periodData = await db.get('SELECT current_period FROM periods WHERE id = 1');
    const currentPeriod = periodData.current_period;

    // 更新用户投资状态
    await db.run(
      'UPDATE users SET invested_project = ? WHERE id = ?',
      [project, req.user.id]
    );

    // 记录历史
    await db.run(
      `INSERT INTO history (user_id, period, action, project) 
       VALUES (?, ?, ?, ?)`,
      [req.user.id, currentPeriod, '确认投资', project]
    );

    res.json({ success: true, message: '投资成功', project });
  } catch (error) {
    console.error('投资错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// ==================== 项目相关 ====================

// 获取所有项目
app.get('/api/projects', authenticateToken, async (req, res) => {
  try {
    const projects = await db.query('SELECT * FROM projects ORDER BY name');
    res.json(projects);
  } catch (error) {
    console.error('获取项目列表错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// 添加项目（仅管理员）
app.post('/api/projects', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { name } = req.body;

    if (!name) {
      return res.status(400).json({ error: '项目名称不能为空' });
    }

    await db.run('INSERT INTO projects (name) VALUES (?)', [name]);
    res.json({ success: true, message: '项目添加成功' });
  } catch (error) {
    if (error.message.includes('UNIQUE constraint failed')) {
      return res.status(400).json({ error: '项目已存在' });
    }
    console.error('添加项目错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// 删除项目（仅管理员）
app.delete('/api/projects/:name', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { name } = req.params;
    await db.run('DELETE FROM projects WHERE name = ?', [name]);
    res.json({ success: true, message: '项目删除成功' });
  } catch (error) {
    console.error('删除项目错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// ==================== 管理员相关 ====================

// 获取所有用户
app.get('/api/admin/users', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const users = await db.query(
      `SELECT id, username, role, credit, initial_credit, invested_project 
       FROM users 
       WHERE role = 'user'
       ORDER BY username`
    );
    res.json(users);
  } catch (error) {
    console.error('获取用户列表错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// 获取当前期数
app.get('/api/admin/period', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const periodData = await db.get('SELECT current_period FROM periods WHERE id = 1');
    res.json({ period: periodData.current_period });
  } catch (error) {
    console.error('获取期数错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// 结算（仅管理员）
app.post('/api/admin/settle', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { marketPercent } = req.body; // { "黄金": 10, "股票": -5, "债券": 3 }

    if (!marketPercent || typeof marketPercent !== 'object') {
      return res.status(400).json({ error: '市场数据格式错误' });
    }

    // 获取当前期数
    const periodData = await db.get('SELECT current_period FROM periods WHERE id = 1');
    const currentPeriod = periodData.current_period;

    // 获取所有已投资的用户
    const investedUsers = await db.query(
      `SELECT id, username, credit, invested_project 
       FROM users 
       WHERE invested_project IS NOT NULL 
       AND role = 'user'`
    );

    let settledCount = 0;

    // 开始事务
    await db.run('BEGIN TRANSACTION');

    try {
      for (const user of investedUsers) {
        const percentage = marketPercent[user.invested_project] || 0;
        const creditBefore = user.credit;
        const creditAfter = creditBefore * (1 + percentage / 100);

        // 更新用户资金
        await db.run(
          'UPDATE users SET credit = ?, invested_project = NULL WHERE id = ?',
          [creditAfter, user.id]
        );

        // 记录历史
        await db.run(
          `INSERT INTO history (user_id, period, action, project, percentage, credit_before, credit_after) 
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [user.id, currentPeriod, '期结算', user.invested_project, percentage, creditBefore, creditAfter]
        );

        settledCount++;
      }

      // 保存市场数据
      for (const [project, percentage] of Object.entries(marketPercent)) {
        await db.run(
          'INSERT INTO market_data (period, project_name, percentage) VALUES (?, ?, ?)',
          [currentPeriod, project, percentage]
        );
      }

      // 更新期数
      await db.run(
        'UPDATE periods SET current_period = current_period + 1 WHERE id = 1'
      );

      await db.run('COMMIT');

      const newPeriodData = await db.get('SELECT current_period FROM periods WHERE id = 1');

      res.json({
        success: true,
        message: '结算完成',
        settledCount,
        newPeriod: newPeriodData.current_period
      });
    } catch (error) {
      await db.run('ROLLBACK');
      throw error;
    }
  } catch (error) {
    console.error('结算错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// 获取用户历史图表数据
app.get('/api/admin/user-chart/:username', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { username } = req.params;

    const user = await db.get('SELECT id FROM users WHERE username = ?', [username]);
    if (!user) {
      return res.status(404).json({ error: '用户不存在' });
    }

    const history = await db.query(
      `SELECT period, credit_after, created_at 
       FROM history 
       WHERE user_id = ? AND action = '期结算'
       ORDER BY period ASC`,
      [user.id]
    );

    res.json(history);
  } catch (error) {
    console.error('获取用户图表数据错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// ==================== 健康检查 ====================
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════╗
║   投资模拟系统后端服务器已启动        ║
║   端口: ${PORT}                         ║
║   环境: ${process.env.NODE_ENV || 'development'}                    ║
╚════════════════════════════════════════╝
  `);
});

// 优雅关闭
process.on('SIGINT', () => {
  console.log('\n正在关闭服务器...');
  db.close();
  process.exit(0);
});
