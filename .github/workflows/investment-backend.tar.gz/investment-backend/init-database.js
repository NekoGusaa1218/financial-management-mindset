const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');

const dbPath = path.join(__dirname, 'database.sqlite');
const db = new sqlite3.Database(dbPath);

// 初始化数据库
db.serialize(() => {
  // 用户表
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      credit REAL NOT NULL DEFAULT 100,
      initial_credit REAL NOT NULL DEFAULT 100,
      invested_project TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // 投资历史表
  db.run(`
    CREATE TABLE IF NOT EXISTS history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      period INTEGER NOT NULL,
      action TEXT NOT NULL,
      project TEXT,
      percentage REAL,
      credit_before REAL,
      credit_after REAL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id)
    )
  `);

  // 投资项目表
  db.run(`
    CREATE TABLE IF NOT EXISTS projects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // 期数管理表
  db.run(`
    CREATE TABLE IF NOT EXISTS periods (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      current_period INTEGER NOT NULL DEFAULT 1
    )
  `);

  // 市场数据表（每期的涨跌百分比）
  db.run(`
    CREATE TABLE IF NOT EXISTS market_data (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      period INTEGER NOT NULL,
      project_name TEXT NOT NULL,
      percentage REAL NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // 插入初始期数
  db.run(`INSERT OR IGNORE INTO periods (id, current_period) VALUES (1, 1)`);

  // 插入初始项目
  const projects = ['黄金', '股票', '债券'];
  const stmt = db.prepare('INSERT OR IGNORE INTO projects (name) VALUES (?)');
  projects.forEach(project => stmt.run(project));
  stmt.finalize();

  // 创建管理员账户
  const adminPassword = bcrypt.hashSync('admin', 10);
  db.run(
    'INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)',
    ['admin', adminPassword, 'admin']
  );

  // 创建40个普通用户
  const userPassword = bcrypt.hashSync('1234', 10);
  const userStmt = db.prepare(
    'INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)'
  );
  for (let i = 1; i <= 40; i++) {
    userStmt.run(`user${i}`, userPassword, 'user');
  }
  userStmt.finalize();

  console.log('✅ 数据库初始化完成！');
  console.log('管理员账号: admin / admin');
  console.log('用户账号: user1-user40 / 1234');
});

db.close();
